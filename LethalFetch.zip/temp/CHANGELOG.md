# 0.1.2

Fixed typos.

# 0.1.1

Fixed terminal not opening :|, now it's actually usable

# 0.1.0

Fixed manifest :|

# 0.0.1

Released!
