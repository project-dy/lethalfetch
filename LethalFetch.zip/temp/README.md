
# neofetch, now in lethal company's terminal

```shell
>neofetch
+---------+ OS: Fortune OS
|         | Kernel: GNU/Hurd 0.1.2-3
| (image) | Uptime: 5 minutes, 35 seconds
|         | Packages: 6 (braken) 9 (rpm)
+---------+ Shell: quota
            Terminal: VT-33000
            CPU: BORSON 300 @ 2500 MH
            GPU: Nvidia Tesla V900
            Memory:  129 MiB / 448 MiB
```
